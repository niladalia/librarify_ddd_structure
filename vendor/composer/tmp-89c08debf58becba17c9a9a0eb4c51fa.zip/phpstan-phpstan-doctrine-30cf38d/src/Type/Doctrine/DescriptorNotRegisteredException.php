<?php declare(strict_types = 1);

namespace PHPStan\Type\Doctrine;

use RuntimeException;

class DescriptorNotRegisteredException extends RuntimeException
{

}
