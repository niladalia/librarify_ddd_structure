<?php
$pipes = [];
proc_open('', [], $pipes);

