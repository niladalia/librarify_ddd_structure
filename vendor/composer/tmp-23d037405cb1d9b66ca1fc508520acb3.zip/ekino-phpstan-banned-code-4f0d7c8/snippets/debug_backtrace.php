<?php

debug_backtrace();
