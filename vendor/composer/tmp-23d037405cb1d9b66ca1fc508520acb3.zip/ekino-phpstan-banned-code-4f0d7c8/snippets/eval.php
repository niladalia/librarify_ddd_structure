<?php

eval(true);

